package com.travelease;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelEaseApplication {
    public static void main(String[] args) {
        SpringApplication.run(TravelEaseApplication.class, args);
    }
}
